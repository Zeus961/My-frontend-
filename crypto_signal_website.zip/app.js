const firebaseConfig = {
    apiKey: "YOUR_FIREBASE_API_KEY",
    authDomain: "YOUR_FIREBASE_AUTH_DOMAIN",
    projectId: "YOUR_FIREBASE_PROJECT_ID",
    storageBucket: "YOUR_FIREBASE_STORAGE_BUCKET",
    messagingSenderId: "YOUR_FIREBASE_MESSAGING_SENDER_ID",
    appId: "YOUR_FIREBASE_APP_ID"
};
firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();

document.getElementById('loginBtn').addEventListener('click', () => {
    const email = prompt('Enter email:');
    const password = prompt('Enter password:');
    auth.signInWithEmailAndPassword(email, password).then(() => {
        document.getElementById('loginBtn').style.display = 'none';
        document.getElementById('logoutBtn').style.display = 'inline';
    }).catch(error => alert(error.message));
});

document.getElementById('logoutBtn').addEventListener('click', () => {
    auth.signOut().then(() => {
        document.getElementById('loginBtn').style.display = 'inline';
        document.getElementById('logoutBtn').style.display = 'none';
    });
});

function subscribeAlert() {
    const email = document.getElementById('email').value;
    if (!email) { alert('Enter email'); return; }
    alert('Subscribed successfully!');
}

async function fetchCryptoSignals() {
    const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd');
    const data = await response.json();
    const table = document.getElementById('signal-table');
    table.innerHTML += `<tr><td>BTC/USDT</td><td>${data.bitcoin.usd > 50000 ? 'BUY' : 'SELL'}</td><td>${new Date().toLocaleTimeString()}</td></tr>`;
}

setInterval(fetchCryptoSignals, 60000);
fetchCryptoSignals();
